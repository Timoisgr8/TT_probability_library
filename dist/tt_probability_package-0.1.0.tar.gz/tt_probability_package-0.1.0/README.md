

Test cases:

Run python -m unittest discover tests